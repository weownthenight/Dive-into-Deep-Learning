## About
This is a mini deep learning framework created by Zhang Ying.

## Features

+ Define Dynamic Computing Graph
+ Define Neural Network Operator
+ Define Linear, Sigmoid, L2_Loss
+ Auto-Diff Computing
+ Auto-Feedforward and Backward

## Remain
+ Classification
+ Cross-Entropy
+ CNN, RNN

## Connection
Email: alexandrea@126.com
